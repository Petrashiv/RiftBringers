﻿namespace RiftBringers.Battle
{
    public enum BattleActionType
    {
        Attack,
        Defend,
        Skill
    }
}