﻿namespace RiftBringers.Items
{
    public enum ItemType
    {
        Helmet,      
        Chestplate,  
        Pants,       
        Boots,       
        Weapon,      
        Amulet       
    }
}